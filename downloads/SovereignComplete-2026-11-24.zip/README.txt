Pokemon Sovereign Complete: November 24, 2026 release
=====================================================

Johto and Kanto, from Drayano's Sacred Gold, joined to Sovereign Platinum's Sinnoh: one game,
three regions, from New Bark Town to Sinnoh's Hall of Fame.

This zip holds patches, not a game. You apply a patch to your own copy of Pokemon Platinum
(US), dumped from a cartridge you own.

WHAT'S IN THE ZIP
  SovereignComplete4997.xdelta   for a Pokemon Platinum (US) Rev 1 dump
  SovereignComplete3541.xdelta   for a Pokemon Platinum (US) Rev 0 dump
  README.txt                     this file

Both patches make the same game. Use the one that matches your dump.

1. DUMP YOUR CARTRIDGE
   Dump your own Pokemon Platinum (US) cartridge to an .nds file: with a modded DS or 3DS
   (GodMode9i on a DSi or 3DS, for example) or a cartridge dumper. Don't patch a file that
   has already been patched or trimmed.

2. FIND YOUR REVISION
   Check your dump's SHA-1 or CRC32 (ROM Patcher JS shows both when you open the file):

     Rev 1 (use SovereignComplete4997.xdelta)
       SHA-1  0862ec35b24de5c7e2dcb88c9eea0873110d755c
       CRC32  69D628E8
     Rev 0 (use SovereignComplete3541.xdelta)
       SHA-1  ce81046eda7d232513069519cb2085349896dec7
       CRC32  9253921D

   If it matches neither, your dump isn't a clean US Platinum and the patch won't work.

3. APPLY THE PATCH (any one of these)
   - In a browser: ROM Patcher JS, https://www.marcrobledo.com/RomPatcher.js/
     Choose your dump as the ROM file and the matching .xdelta as the patch, then
     "Apply patch" and save the result.
   - On Windows: Delta Patcher. Original file: your dump; XDelta patch: the .xdelta;
     "Apply patch".
   - On the command line (xdelta3, any system):
       xdelta3 -d -s "Pokemon Platinum (US).nds" SovereignComplete4997.xdelta "Sovereign Complete.nds"

4. CHECK THE RESULT
   The patched game is 256 MB (Sovereign makes the cartridge bigger). Its SHA-1 should be:
       a607b48b1bc05e51d1eb7a34dea572fdd159cfe5
   Play it on a DS emulator (melonDS or DeSmuME) or a flashcart.

SAVES
   Use a new save file. A save from Pokemon Platinum or an older build of Sovereign Platinum
   won't carry over.

CREDITS
   Sovereign Platinum's engine and its Sinnoh, Drayano's Sacred Gold for Johto and Kanto, and
   the pret decompilations of Platinum and HeartGold that both are built from.

Progress, screenshots and the latest release: https://hanktwichell.github.io/pokemon-sovereign-progress/
